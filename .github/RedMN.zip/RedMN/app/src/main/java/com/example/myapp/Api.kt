package com.example.myapp

import android.os.Build
import android.text.Html
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Api {
    private const val QUERY =
        "query(\$page:Int,\$perPage:Int,\$search:String,\$type:MediaType,\$country:CountryCode," +
        "\$genre:String,\$status:MediaStatus,\$sort:[MediaSort]){" +
        "Page(page:\$page,perPage:\$perPage){media(type:\$type,search:\$search,countryOfOrigin:\$country," +
        "genre:\$genre,status:\$status,sort:\$sort,isAdult:false){" +
        "id title{romaji english} coverImage{large} averageScore " +
        "description(asHtml:false) format episodes chapters genres}}}"

    private fun str(o: JSONObject, k: String): String =
        if (o.isNull(k)) "" else o.optString(k)

    private fun clean(s: String): String {
        if (s.isEmpty()) return "توضیحاتی موجود نیست."
        val t = if (Build.VERSION.SDK_INT >= 24)
            Html.fromHtml(s, Html.FROM_HTML_MODE_LEGACY).toString()
        else @Suppress("DEPRECATION") Html.fromHtml(s).toString()
        return t.trim()
    }

    fun fetch(
        kindIdx: Int, query: String?, genre: String?, status: String?,
        sort: String, page: Int, perPage: Int
    ): List<Media> {
        val k = KINDS[kindIdx]
        val vars = JSONObject()
            .put("page", page).put("perPage", perPage)
            .put("type", k.type).put("sort", JSONArray().put(sort))
        if (!query.isNullOrBlank()) vars.put("search", query.trim())
        if (k.country != null) vars.put("country", k.country)
        if (!genre.isNullOrEmpty()) vars.put("genre", genre)
        if (!status.isNullOrEmpty()) vars.put("status", status)
        val body = JSONObject().put("query", QUERY).put("variables", vars).toString()

        val conn = URL("https://graphql.anilist.co").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("Accept", "application/json")
        conn.connectTimeout = 15000
        conn.readTimeout = 15000
        conn.doOutput = true
        conn.outputStream.use { it.write(body.toByteArray()) }
        val code = conn.responseCode
        if (code !in 200..299) throw Exception("HTTP $code")
        val text = conn.inputStream.bufferedReader().use { it.readText() }

        val arr = JSONObject(text).getJSONObject("data").getJSONObject("Page").getJSONArray("media")
        val out = ArrayList<Media>()
        for (i in 0 until arr.length()) {
            val m = arr.getJSONObject(i)
            val t = m.getJSONObject("title")
            val title = str(t, "english").ifEmpty { str(t, "romaji") }
            val cover = if (m.isNull("coverImage")) "" else str(m.getJSONObject("coverImage"), "large")
            val parts = ArrayList<String>()
            val format = str(m, "format")
            if (format.isNotEmpty()) parts.add(format)
            if (!m.isNull("episodes")) parts.add("${m.optInt("episodes")} قسمت")
            if (!m.isNull("chapters")) parts.add("${m.optInt("chapters")} فصل")
            val g = m.optJSONArray("genres")
            if (g != null) for (j in 0 until minOf(3, g.length())) parts.add(g.getString(j))
            out.add(Media(
                m.optInt("id"), title, cover, m.optInt("averageScore"),
                clean(str(m, "description")), parts.joinToString(" • "), k.key
            ))
        }
        return out
    }
}
