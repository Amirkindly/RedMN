package com.example.myapp

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.util.UUID
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

const val OWNER_NAME = "amir#2000"
private const val OWNER_PASS = "amir#2000"

class Db(ctx: Context) {
    private val up = ctx.getSharedPreferences("users", Context.MODE_PRIVATE)
    private val sp = ctx.getSharedPreferences("app", Context.MODE_PRIVATE)

    private val signKey = "RedMN-account-signing-key-change-me"

    fun sha(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    private fun hmac(data: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(signKey.toByteArray(), "HmacSHA256"))
        return mac.doFinal(data.toByteArray()).joinToString("") { "%02x".format(it) }
    }

    // ---------- تنظیمات ----------
    var dark: Boolean
        get() = sp.getBoolean("dark", false)
        set(v) { sp.edit().putBoolean("dark", v).apply() }
    var textScale: Int
        get() = sp.getInt("textScale", 1)
        set(v) { sp.edit().putInt("textScale", v).apply() }
    var homeCat: Int
        get() = sp.getInt("homeCat", 0)
        set(v) { sp.edit().putInt("homeCat", v).apply() }
    var sessionUser: String?
        get() = sp.getString("session", null)
        set(v) { sp.edit().putString("session", v).apply() }

    // ---------- کاربرها ----------
    private fun usersObj(): JSONObject = try {
        JSONObject(up.getString("all", "{}") ?: "{}")
    } catch (e: Exception) { JSONObject() }

    fun getUser(n: String): User? = usersObj().optJSONObject(n.lowercase())?.let { User.fromJson(it) }

    fun saveUser(u: User) {
        val o = usersObj()
        o.put(u.username.lowercase(), u.toJson())
        up.edit().putString("all", o.toString()).apply()
    }

    fun allUsers(): List<User> {
        val o = usersObj()
        val out = ArrayList<User>()
        for (k in o.keys()) out.add(User.fromJson(o.getJSONObject(k)))
        return out.sortedBy { it.username.lowercase() }
    }

    fun deleteUser(n: String) {
        val o = usersObj()
        o.remove(n.lowercase())
        up.edit().putString("all", o.toString()).apply()
        sp.edit().remove(bmKey(n)).apply()
        if (sessionUser?.lowercase() == n.lowercase()) sessionUser = null
    }

    fun currentUser(): User? = sessionUser?.let { getUser(it) }

    fun checkLogin(n: String, p: String): User? {
        val u = getUser(n) ?: return null
        return if (sha(u.salt + p) == u.hash) u else null
    }

    fun register(username: String, pass: String, name: String, role: String = "user", vipMonths: Int = 0): String? {
        if (!Regex("^[A-Za-z0-9_]{3,20}$").matches(username))
            return "نام کاربری باید ۳ تا ۲۰ حرف انگلیسی/عدد/_ باشه"
        if (pass.length < 4) return "رمز باید حداقل ۴ کاراکتر باشه"
        if (getUser(username) != null) return "این نام کاربری قبلاً گرفته شده"
        val salt = UUID.randomUUID().toString().take(8)
        val vip = if (vipMonths > 0) System.currentTimeMillis() + vipMonths * 30L * DAY_MS else 0L
        saveUser(User(username, if (name.isBlank()) username else name, salt, sha(salt + pass),
            role, vip, 0, "", emptyList(), ""))
        return null
    }

    fun seedOwner() {
        val old = getUser("amir")
        if (old != null && old.role == "owner") deleteUser("amir")
        if (getUser(OWNER_NAME) == null) {
            val salt = UUID.randomUUID().toString().take(8)
            saveUser(User(OWNER_NAME, "امیر", salt, sha(salt + OWNER_PASS), "owner", 0L, 0, "", emptyList(), ""))
        }
    }

    // ---------- نشانک‌ها ----------
    private fun bmKey(n: String) = "bm_" + n.lowercase()

    fun bookmarks(n: String): List<Media> {
        val arr = try { JSONArray(sp.getString(bmKey(n), "[]")) } catch (e: Exception) { JSONArray() }
        val out = ArrayList<Media>()
        for (i in 0 until arr.length()) out.add(Media.fromJson(arr.getJSONObject(i)))
        return out
    }

    private fun saveBm(n: String, list: List<Media>) {
        val arr = JSONArray()
        for (m in list) arr.put(m.toJson())
        sp.edit().putString(bmKey(n), arr.toString()).apply()
    }

    fun isBookmarked(n: String, id: Int) = bookmarks(n).any { it.id == id }

    fun addBookmark(n: String, m: Media) {
        val list = bookmarks(n).toMutableList()
        if (list.none { it.id == m.id }) list.add(0, m.copy(desc = m.desc.take(800)))
        saveBm(n, list)
    }

    fun removeBookmark(n: String, id: Int) = saveBm(n, bookmarks(n).filter { it.id != id })

    // ---------- فایل اکانت ----------
    fun exportAccount(n: String): String {
        val u = getUser(n) ?: return ""
        val arr = JSONArray()
        for (m in bookmarks(n)) arr.put(m.toJson())
        val data = JSONObject().put("user", u.toJson()).put("bookmarks", arr).toString()
        return JSONObject().put("app", "RedMN").put("data", data).put("sig", hmac(data)).toString()
    }

    fun importAccount(text: String, login: Boolean = true): String? {
        try {
            val o = JSONObject(text)
            if (o.optString("app") != "RedMN") return "این فایل مربوط به RedMN نیست"
            val data = o.getString("data")
            if (hmac(data) != o.getString("sig")) return "فایل معتبر نیست یا دستکاری شده"
            val d = JSONObject(data)
            val u = User.fromJson(d.getJSONObject("user"))
            saveUser(u)
            val arr = d.optJSONArray("bookmarks") ?: JSONArray()
            sp.edit().putString(bmKey(u.username), arr.toString()).apply()
            if (login) sessionUser = u.username
            return null
        } catch (e: Exception) {
            return "خواندن فایل ناموفق بود"
        }
    }
}
