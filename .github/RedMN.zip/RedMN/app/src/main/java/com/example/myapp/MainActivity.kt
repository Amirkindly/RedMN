package com.example.myapp

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.text.TextUtils
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

private val HOME_CATS = listOf("جدیدترین‌ها", "انیمه‌های در حال پخش", "کارهای پایان‌یافته")
private val HOME_STATUS = listOf("RELEASING", "RELEASING", "FINISHED")
private val HOME_SORT = listOf("START_DATE_DESC", "POPULARITY_DESC", "SCORE_DESC")
private val ROW_TITLES = listOf(
    listOf("جدیدترین انیمه‌ها", "جدیدترین مانگاها", "جدیدترین مانهواها"),
    listOf("انیمه‌های در حال پخش", "مانگاهای در حال انتشار", "مانهواهای در حال انتشار"),
    listOf("انیمه‌های پایان‌یافته", "مانگاهای پایان‌یافته", "مانهواهای پایان‌یافته")
)
private val NAV = listOf("🏠" to "خانه", "🔖" to "نشانک‌ها", "⚙️" to "تنظیمات", "🧭" to "اکسپلور", "👤" to "پروفایل")

class MainActivity : Activity() {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val ACCENT = Color.parseColor("#E53935")
    private val PASS = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
    private val REQ_EXPORT = 101
    private val REQ_IMPORT = 102
    private val REQ_IMPORT_ADMIN = 103

    private lateinit var db: Db
    private lateinit var container: FrameLayout
    private val navItems = ArrayList<TextView>()
    private var dark = false
    private var scale = 1f
    private var tab = 0
    private var homeCat = 0
    private val homeCache = HashMap<String, List<Media>>()
    private var pendingExport = ""

    // اکسپلور
    private var exKind = 0
    private var exGenre = 0
    private var exQuery = ""
    private var exPage = 1
    private var exReq = 0
    private val exItems = ArrayList<Media>()
    private lateinit var exAdapter: MediaAdapter
    private lateinit var exStatus: TextView
    private lateinit var exMore: Button

    // ---------- رنگ‌ها و ابزارهای ساخت UI ----------
    private val cBg get() = if (dark) Color.parseColor("#121212") else Color.WHITE
    private val cCard get() = if (dark) Color.parseColor("#232330") else Color.parseColor("#F4F2F2")
    private val cText get() = if (dark) Color.parseColor("#EEEEEE") else Color.parseColor("#111111")
    private val cSub get() = if (dark) Color.parseColor("#A8A8B0") else Color.parseColor("#666666")

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun ts(x: Float) = x * scale
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    private fun scoreText(m: Media) = if (m.score > 0) "⭐ ${m.score}/100" else "بدون امتیاز"

    private fun lp(w: Int, h: Int, weight: Float = 0f, m: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h, weight)
        p.setMargins(m, m, m, m)
        return p
    }

    private fun round(color: Int, r: Int) = GradientDrawable().apply {
        cornerRadius = dp(r).toFloat()
        setColor(color)
    }

    private fun tv(s: String, size: Float = 14f, color: Int = cText, bold: Boolean = false) =
        TextView(this).apply {
            text = s
            textSize = ts(size)
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun btn(label: String, color: Int = ACCENT, click: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(Color.WHITE)
        textSize = ts(14f)
        background = round(color, 12)
        layoutParams = lp(MATCH, WRAP, 0f, dp(4))
        setOnClickListener { click() }
    }

    private fun edit(hintText: String, value: String = "", type: Int = InputType.TYPE_CLASS_TEXT) =
        EditText(this).apply {
            hint = hintText
            setText(value)
            inputType = type
            setTextColor(cText)
            setHintTextColor(cSub)
        }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12))
        background = round(cCard, 14)
        layoutParams = lp(MATCH, WRAP, 0f, dp(6))
    }

    private fun screenTitle(s: String) = tv(s, 22f, ACCENT, true).apply {
        setPadding(dp(16), dp(12), dp(16), dp(4))
    }

    private fun chipRow(opts: List<String>, selected: Int, onSel: (Int) -> Unit): View {
        val row = LinearLayout(this).apply { setPadding(dp(8), dp(6), dp(8), dp(2)) }
        val chips = ArrayList<TextView>()
        opts.forEach { label ->
            val c = TextView(this).apply {
                text = label
                textSize = ts(14f)
                setPadding(dp(14), dp(8), dp(14), dp(8))
                layoutParams = lp(WRAP, WRAP, 0f, dp(4))
            }
            chips.add(c)
            row.addView(c)
        }
        fun paint(sel: Int) {
            chips.forEachIndexed { i, c ->
                c.background = round(if (i == sel) ACCENT else cCard, 20)
                c.setTextColor(if (i == sel) Color.WHITE else cText)
            }
        }
        paint(selected)
        chips.forEachIndexed { i, c -> c.setOnClickListener { paint(i); onSel(i) } }
        return HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(row)
        }
    }

    private fun showSheet(onDismiss: (() -> Unit)? = null, build: (LinearLayout, AlertDialog) -> Unit) {
        val dialog = AlertDialog.Builder(this).create()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(8))
        }
        build(col, dialog)
        dialog.setView(ScrollView(this).apply { addView(col) })
        dialog.window?.setBackgroundDrawable(round(cBg, 16))
        if (onDismiss != null) dialog.setOnDismissListener { onDismiss() }
        dialog.show()
    }

    // ---------- چرخه‌ی برنامه ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        db = Db(this)
        db.seedOwner()
        loadSettings()
        buildUi()
    }

    private fun loadSettings() {
        dark = db.dark
        scale = when (db.textScale) { 0 -> 0.9f; 2 -> 1.2f; else -> 1f }
        homeCat = db.homeCat
    }

    private fun buildUi() {
        window.decorView.setBackgroundColor(cBg)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            fitsSystemWindows = true
            setBackgroundColor(cBg)
        }
        container = FrameLayout(this)
        root.addView(container, lp(MATCH, 0, 1f))

        val nav = LinearLayout(this).apply { setBackgroundColor(cCard) }
        navItems.clear()
        NAV.forEachIndexed { i, (icon, label) ->
            val t = TextView(this).apply {
                text = icon + "\n" + label
                gravity = Gravity.CENTER
                textSize = 11f
                setPadding(0, dp(8), 0, dp(8))
                setOnClickListener { show(i) }
            }
            navItems.add(t)
            nav.addView(t, lp(0, WRAP, 1f))
        }
        root.addView(nav, lp(MATCH, WRAP))
        setContentView(root)
        show(tab)
    }

    private fun show(i: Int) {
        tab = i
        container.removeAllViews()
        container.addView(
            when (i) {
                0 -> buildHome()
                1 -> buildBookmarks()
                2 -> buildSettings()
                3 -> buildExplore()
                else -> buildProfile()
            }
        )
        navItems.forEachIndexed { j, t -> t.setTextColor(if (j == i) ACCENT else cSub) }
    }

    // ---------- خانه ----------
    private fun buildHome(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(screenTitle("RedMN"))
        col.addView(chipRow(HOME_CATS, homeCat) { homeCat = it; db.homeCat = it; show(0) })
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(16))
        }
        for (k in 0..2) addRow(box, homeCat, k)
        col.addView(ScrollView(this).apply { addView(box) }, lp(MATCH, 0, 1f))
        return col
    }

    private fun addRow(box: LinearLayout, cat: Int, kind: Int) {
        box.addView(tv(ROW_TITLES[cat][kind], 17f, cText, true).apply {
            setPadding(dp(16), dp(14), dp(16), dp(6))
        })
        val inner = LinearLayout(this).apply { setPadding(dp(10), 0, dp(10), 0) }
        box.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(inner)
        })
        val key = "$cat-$kind"
        val cached = homeCache[key]
        if (cached != null) { fillRow(inner, cached); return }
        inner.addView(tv("در حال بارگذاری...", 13f, cSub).apply { setPadding(dp(8), dp(8), dp(8), dp(8)) })
        Thread {
            try {
                val r = Api.fetch(kind, null, null, HOME_STATUS[cat], HOME_SORT[cat], 1, 15)
                runOnUiThread { homeCache[key] = r; fillRow(inner, r) }
            } catch (e: Exception) {
                runOnUiThread {
                    inner.removeAllViews()
                    inner.addView(tv("خطا در اتصال به اینترنت", 13f, cSub).apply {
                        setPadding(dp(8), dp(8), dp(8), dp(8))
                    })
                }
            }
        }.start()
    }

    private fun fillRow(inner: LinearLayout, items: List<Media>) {
        inner.removeAllViews()
        if (items.isEmpty()) {
            inner.addView(tv("موردی پیدا نشد", 13f, cSub).apply { setPadding(dp(8), dp(8), dp(8), dp(8)) })
            return
        }
        for (m in items) inner.addView(posterCard(m))
    }

    private fun posterCard(m: Media): View {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = lp(dp(110), WRAP, 0f, dp(4))
            setOnClickListener { showDetail(m) }
        }
        val img = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        c.addView(img, lp(dp(110), dp(155)))
        ImageLoader.load(m.cover, img)
        c.addView(tv(m.title, 12f, cText).apply {
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            setPadding(0, dp(4), 0, 0)
        })
        c.addView(tv(scoreText(m), 11f, ACCENT))
        return c
    }

    // ---------- نشانک‌ها ----------
    private fun buildBookmarks(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(screenTitle("نشانک‌ها"))
        val u = db.currentUser()
        if (u == null) {
            col.addView(tv("برای دیدن نشانک‌ها باید وارد حساب بشی.", 15f, cSub).apply {
                setPadding(dp(16), dp(8), dp(16), dp(4))
            })
            col.addView(buildLogin(), lp(MATCH, 0, 1f))
            return col
        }
        val items = db.bookmarks(u.username)
        col.addView(tv("${items.size} / ${bmLimit(u)}" + (if (isVip(u)) "   ⭐ VIP" else ""), 13f, cSub).apply {
            setPadding(dp(16), 0, dp(16), dp(8))
        })
        if (items.isEmpty()) {
            col.addView(tv("هنوز نشانکی نداری.\nتوی صفحه‌ی هر عنوان دکمه‌ی «نشانک» رو بزن.", 14f, cSub).apply {
                setPadding(dp(16), dp(16), dp(16), dp(8))
            })
        }
        val list = ListView(this).apply {
            divider = null
            adapter = MediaAdapter(items, false)
            setOnItemClickListener { _, _, p, _ -> showDetail(items[p]) }
        }
        col.addView(list, lp(MATCH, 0, 1f))
        return col
    }

    // ---------- تنظیمات ----------
    private fun buildSettings(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(24))
        }
        col.addView(screenTitle("تنظیمات صفحه‌ها"))

        col.addView(tv("ظاهر برنامه", 15f, cText, true).apply { setPadding(dp(16), dp(14), dp(16), 0) })
        col.addView(chipRow(listOf("☀️ روشن", "🌙 تاریک"), if (dark) 1 else 0) {
            db.dark = (it == 1)
            loadSettings()
            buildUi()
        })

        col.addView(tv("اندازه‌ی متن", 15f, cText, true).apply { setPadding(dp(16), dp(14), dp(16), 0) })
        col.addView(chipRow(listOf("کوچک", "متوسط", "بزرگ"), db.textScale) {
            db.textScale = it
            loadSettings()
            buildUi()
        })

        col.addView(tv("دسته‌ی پیش‌فرض صفحه‌ی خانه", 15f, cText, true).apply { setPadding(dp(16), dp(14), dp(16), 0) })
        col.addView(chipRow(HOME_CATS, homeCat) {
            homeCat = it
            db.homeCat = it
            toast("ذخیره شد")
        })

        col.addView(tv("RedMN نسخه‌ی ۱٫۰\nاطلاعات عناوین از AniList گرفته می‌شه.", 12f, cSub).apply {
            setPadding(dp(16), dp(24), dp(16), 0)
        })
        return ScrollView(this).apply { addView(col) }
    }

    // ---------- اکسپلور ----------
    private fun buildExplore(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(screenTitle("اکسپلور"))
        col.addView(chipRow(KINDS.map { it.label }, exKind) { exKind = it; exSearch(true) })
        col.addView(chipRow(GENRES.map { it.first }, exGenre) { exGenre = it; exSearch(true) })

        val row = LinearLayout(this).apply { setPadding(dp(12), dp(8), dp(12), dp(4)) }
        val box = edit("جستجو (مثلاً Solo Leveling)", exQuery).apply {
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_SEARCH
        }
        box.setOnEditorActionListener { _, _, _ ->
            exQuery = box.text.toString()
            exSearch(true)
            true
        }
        row.addView(box, lp(0, WRAP, 1f))
        row.addView(btn("جستجو") {
            exQuery = box.text.toString()
            exSearch(true)
        }.apply { layoutParams = lp(WRAP, WRAP, 0f, dp(2)) })
        col.addView(row)

        exStatus = tv("", 13f, cSub).apply { gravity = Gravity.CENTER }
        col.addView(exStatus)

        exAdapter = MediaAdapter(exItems, true)
        val list = ListView(this).apply {
            divider = null
            adapter = exAdapter
            setOnItemClickListener { _, _, p, _ -> if (p < exItems.size) showDetail(exItems[p]) }
        }
        col.addView(list, lp(MATCH, 0, 1f))
        exMore = btn("نمایش بیشتر") { exSearch(false) }
        col.addView(exMore)

        if (exItems.isEmpty()) exSearch(true) else exMore.visibility = View.VISIBLE
        return col
    }

    private fun exSearch(reset: Boolean) {
        if (reset) {
            exPage = 1
            exItems.clear()
            exAdapter.notifyDataSetChanged()
        }
        val my = ++exReq
        exStatus.text = "در حال بارگذاری..."
        val q = exQuery
        val k = exKind
        val g = GENRES[exGenre].second
        val page = exPage
        Thread {
            try {
                val r = Api.fetch(k, q, g, null, "POPULARITY_DESC", page, 20)
                runOnUiThread {
                    if (my != exReq) return@runOnUiThread
                    exItems.addAll(r)
                    exPage++
                    exAdapter.notifyDataSetChanged()
                    exStatus.text = if (exItems.isEmpty()) "نتیجه‌ای پیدا نشد" else ""
                    exMore.visibility = if (r.size >= 20) View.VISIBLE else View.GONE
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (my == exReq) exStatus.text = "خطا در اتصال. اینترنت رو چک کن."
                }
            }
        }.start()
    }

    // ---------- جزئیات ----------
    private fun showDetail(m: Media) {
        showSheet(onDismiss = { if (tab == 1) show(1) }) { c, d ->
            val img = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
            c.addView(img, lp(MATCH, dp(240)))
            ImageLoader.load(m.cover, img)
            c.addView(tv(m.title, 20f, cText, true).apply { setPadding(0, dp(10), 0, dp(4)) })
            c.addView(tv(scoreText(m) + (if (m.info.isNotEmpty()) "\n" + m.info else ""), 13f, cSub))
            c.addView(tv(m.desc, 14f, cText).apply { setPadding(0, dp(10), 0, dp(10)) })

            val cu = db.currentUser()
            val saved = cu != null && db.isBookmarked(cu.username, m.id)
            c.addView(btn(if (saved) "✓ در نشانک‌ها (برای حذف بزن)" else "🔖 نشانک") {
                val u = db.currentUser()
                if (u == null) {
                    toast("برای نشانک کردن اول وارد حساب شو")
                    return@btn
                }
                if (db.isBookmarked(u.username, m.id)) {
                    db.removeBookmark(u.username, m.id)
                    toast("از نشانک‌ها حذف شد")
                } else {
                    val limit = bmLimit(u)
                    if (db.bookmarks(u.username).size >= limit) {
                        toast("به سقف $limit نشانک رسیدی" + (if (!isVip(u)) " — با VIP می‌شه $BM_LIMIT_VIP تا" else ""))
                        return@btn
                    }
                    db.addBookmark(u.username, m)
                    toast("به نشانک‌ها اضافه شد 🔖")
                }
                d.dismiss()
            })
            c.addView(btn("بستن", Color.GRAY) { d.dismiss() })
        }
    }

    // ---------- پروفایل ----------
    private fun buildProfile(): View {
        val u = db.currentUser()
        return if (u == null) buildLogin() else buildAccount(u)
    }

    private fun buildLogin(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), 0, dp(16), dp(24))
        }
        if (tab == 4) col.addView(screenTitle("ورود / ساخت حساب").apply { setPadding(0, dp(12), 0, dp(8)) })
        val un = edit("نام کاربری (انگلیسی)")
        val pw = edit("رمز عبور", "", PASS)
        val nm = edit("نام نمایشی (فقط برای ساخت حساب)")
        col.addView(un); col.addView(pw); col.addView(nm)
        col.addView(btn("ورود") {
            val u = db.checkLogin(un.text.toString().trim(), pw.text.toString())
            if (u == null) toast("نام کاربری یا رمز اشتباهه")
            else { db.sessionUser = u.username; show(tab) }
        })
        col.addView(btn("ساخت حساب جدید", Color.parseColor("#455A64")) {
            val name = un.text.toString().trim()
            val err = db.register(name, pw.text.toString(), nm.text.toString().trim())
            if (err != null) toast(err)
            else { db.sessionUser = name; toast("حساب ساخته شد 🎉"); show(tab) }
        })
        col.addView(btn("📂 ورود با فایل اکانت", Color.GRAY) { pickAccountFile() })
        return ScrollView(this).apply { addView(col) }
    }

    private fun vipText(u: User): String {
        if (u.role == "owner") return "👑 مالک — VIP دائمی"
        val left = u.vipUntil - System.currentTimeMillis()
        if (left <= 0) return "کاربر عادی"
        return "⭐ VIP — ${left / DAY_MS + 1} روز مانده"
    }

    private fun avatar(u: User, sizeDp: Int): View {
        val f = FRAMES.find { it.id == u.frame }
        val bg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(ACCENT)
            setStroke(dp(if (f != null) 6 else 2), f?.color ?: Color.GRAY)
        }
        return TextView(this).apply {
            text = u.name.take(1).uppercase()
            gravity = Gravity.CENTER
            textSize = ts(30f)
            setTextColor(Color.WHITE)
            background = bg
            layoutParams = lp(dp(sizeDp), dp(sizeDp))
        }
    }

    private fun buildAccount(u: User): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(12), dp(8), dp(24))
        }

        val head = card().apply { gravity = Gravity.CENTER_HORIZONTAL }
        head.addView(avatar(u, 88))
        head.addView(tv(u.name, 20f, cText, true).apply { setPadding(0, dp(8), 0, 0) })
        head.addView(tv("@${u.username}", 13f, cSub))
        head.addView(tv(vipText(u), 14f, if (isVip(u)) ACCENT else cSub, true))
        head.addView(btn("✏️ تغییر نام نمایشی") { editNameSheet(u) })
        head.addView(btn("🔑 تغییر رمز عبور", Color.parseColor("#455A64")) { changePassSheet(u) })
        col.addView(head)

        // VIP
        val vip = card()
        vip.addView(tv("⭐ VIP — $VIP_PRICE_TEXT", 17f, cText, true))
        vip.addView(tv("• سقف نشانک‌ها از $BM_LIMIT به $BM_LIMIT_VIP\n• خرید قاب پروفایل با سکه\n• جایزه‌ی روزانه‌ی شانسی: ۵۰ تا ۳۰۰ سکه", 13f, cSub).apply {
            setPadding(0, dp(6), 0, dp(6))
        })
        if (u.role != "owner") vip.addView(btn("خرید / تمدید VIP") { buyVipSheet(u) })
        col.addView(vip)

        // سکه و قاب
        val coins = card()
        coins.addView(tv("🪙 سکه و قاب‌ها", 17f, cText, true))
        if (!isVip(u)) {
            coins.addView(tv("🔒 سکه‌ی روزانه و خرید قاب مخصوص کاربران VIP هست.", 13f, cSub).apply {
                setPadding(0, dp(6), 0, 0)
            })
        } else {
            coins.addView(tv("موجودی: ${u.coins} سکه", 15f, ACCENT, true).apply { setPadding(0, dp(6), 0, dp(4)) })
            val claimed = u.lastDaily == today()
            coins.addView(btn(if (claimed) "جایزه‌ی امروز گرفته شد ✓ (فردا دوباره)" else "🎁 جایزه‌ی روزانه (۵۰ تا ۳۰۰ سکه)",
                if (claimed) Color.GRAY else ACCENT) {
                if (claimed) { toast("امروز جایزه‌ات رو گرفتی"); return@btn }
                val r = Random.nextInt(50, 301)
                u.coins += r
                u.lastDaily = today()
                db.saveUser(u)
                toast("🎉 $r سکه گرفتی!")
                show(4)
            })
            for (f in FRAMES) {
                val owned = u.frames.contains(f.id)
                val equipped = u.frame == f.id
                val row = LinearLayout(this).apply {
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, dp(6), 0, dp(6))
                }
                val dot = View(this).apply {
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setStroke(dp(5), f.color)
                    }
                }
                row.addView(dot, lp(dp(34), dp(34)))
                val names = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(10), 0, dp(10), 0)
                }
                names.addView(tv("قاب ${f.name}", 14f, cText, true))
                names.addView(tv(if (owned) "خریداری شده" else "${f.price} سکه", 12f, cSub))
                row.addView(names, lp(0, WRAP, 1f))
                val label = if (equipped) "در حال استفاده ✓" else if (owned) "استفاده" else "خرید"
                row.addView(btn(label, if (equipped) Color.GRAY else ACCENT) {
                    if (equipped) {
                        u.frame = ""
                    } else if (owned) {
                        u.frame = f.id
                    } else {
                        if (u.coins < f.price) { toast("سکه‌ی کافی نداری"); return@btn }
                        u.coins -= f.price
                        u.frames = u.frames + f.id
                        u.frame = f.id
                        toast("قاب ${f.name} خریداری شد")
                    }
                    db.saveUser(u)
                    show(4)
                }.apply { layoutParams = lp(WRAP, WRAP, 0f, dp(2)) })
                coins.addView(row)
            }
        }
        col.addView(coins)

        // پنل مالک
        if (u.role == "owner") {
            val own = card()
            own.addView(tv("👑 پنل مالک", 17f, cText, true))
            own.addView(btn("➕ ساخت کاربر جدید") { createUserSheet() })
            own.addView(btn("👥 مدیریت کاربران، سکه و VIP", Color.parseColor("#455A64")) { manageUsersSheet() })
            own.addView(btn("📥 افزودن اکانت از فایل (بدون ورود)", Color.parseColor("#455A64")) { pickAccountFile(REQ_IMPORT_ADMIN) })
            col.addView(own)
        }

        // فایل اکانت و خروج
        val acc = card()
        acc.addView(tv("💾 فایل اکانت", 17f, cText, true))
        acc.addView(tv("اکانتت (با نشانک‌ها و سکه‌ها) رو توی یه فایل ذخیره کن تا بعداً یا روی گوشی دیگه واردش بشی. فایل رو پیش خودت نگه دار.", 12f, cSub).apply {
            setPadding(0, dp(4), 0, dp(4))
        })
        acc.addView(btn("💾 ذخیره‌ی اکانت در فایل") { startExport(u.username) })
        acc.addView(btn("📂 ورود با فایل اکانت", Color.parseColor("#455A64")) { pickAccountFile() })
        acc.addView(btn("خروج از حساب", Color.GRAY) { db.sessionUser = null; toast("از حساب خارج شدی"); show(4) })
        col.addView(acc)

        return ScrollView(this).apply { addView(col) }
    }

    private fun startExport(username: String) {
        pendingExport = db.exportAccount(username)
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "application/json"
        i.putExtra(Intent.EXTRA_TITLE, "RedMN-" + username.replace("#", "_") + ".json")
        startActivityForResult(i, REQ_EXPORT)
    }

    private fun pickAccountFile(req: Int = REQ_IMPORT) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        startActivityForResult(i, req)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            if (requestCode == REQ_EXPORT) {
                contentResolver.openOutputStream(uri)?.use { it.write(pendingExport.toByteArray()) }
                toast("اکانت ذخیره شد ✓")
            } else if (requestCode == REQ_IMPORT_ADMIN) {
                val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                val err = db.importAccount(text, false)
                if (err != null) toast(err) else { toast("اکانت به پنل اضافه شد ✓"); manageUsersSheet() }
            } else if (requestCode == REQ_IMPORT) {
                val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                val err = db.importAccount(text)
                if (err != null) toast(err) else { toast("وارد اکانت شدی ✓"); show(4) }
            }
        } catch (e: Exception) {
            toast("خطا: ${e.message}")
        }
    }

    // ---------- شیت‌های پروفایل ----------
    private fun editNameSheet(u: User) = showSheet { c, d ->
        val e = edit("نام نمایشی", u.name)
        c.addView(tv("نام نمایشی", 18f, cText, true))
        c.addView(e)
        c.addView(btn("ذخیره") {
            val n = e.text.toString().trim()
            if (n.isEmpty()) { toast("نام نباید خالی باشه"); return@btn }
            u.name = n
            db.saveUser(u)
            d.dismiss()
            show(4)
        })
    }

    private fun changePassSheet(u: User) = showSheet { c, d ->
        val old = edit("رمز فعلی", "", PASS)
        val nw = edit("رمز جدید (حداقل ۴ کاراکتر)", "", PASS)
        c.addView(tv("تغییر رمز عبور", 18f, cText, true))
        c.addView(old)
        c.addView(nw)
        c.addView(btn("تغییر رمز") {
            if (db.checkLogin(u.username, old.text.toString()) == null) { toast("رمز فعلی اشتباهه"); return@btn }
            val p = nw.text.toString()
            if (p.length < 4) { toast("رمز جدید خیلی کوتاهه"); return@btn }
            u.hash = db.sha(u.salt + p)
            db.saveUser(u)
            toast("رمز تغییر کرد ✓")
            d.dismiss()
        })
    }

    private fun buyVipSheet(u: User) = showSheet { c, d ->
        c.addView(tv("خرید VIP", 18f, cText, true))
        c.addView(tv("قیمت: $VIP_PRICE_TEXT\n\nپرداخت آنلاین هنوز به برنامه وصل نشده. برای خرید، به مالک برنامه پیام بده و نام کاربری‌ات (@${u.username}) رو بفرست تا حسابت VIP بشه.", 14f, cText).apply {
            setPadding(0, dp(8), 0, dp(8))
        })
        c.addView(btn("باشه") { d.dismiss() })
    }

    private fun createUserSheet() = showSheet { c, d ->
        val un = edit("نام کاربری (انگلیسی)")
        val pw = edit("رمز عبور", "", PASS)
        val nm = edit("نام نمایشی (اختیاری)")
        val mo = edit("ماه VIP (۰ = بدون VIP)", "0", InputType.TYPE_CLASS_NUMBER)
        val co = edit("سکه‌ی اولیه", "0", InputType.TYPE_CLASS_NUMBER)
        c.addView(tv("ساخت کاربر جدید", 18f, cText, true))
        c.addView(un); c.addView(pw); c.addView(nm); c.addView(mo); c.addView(co)
        c.addView(btn("ساخت کاربر") {
            val months = mo.text.toString().toIntOrNull() ?: 0
            val name = un.text.toString().trim()
            val err = db.register(name, pw.text.toString(), nm.text.toString().trim(), "user", months)
            if (err != null) { toast(err); return@btn }
            val coins = co.text.toString().toIntOrNull() ?: 0
            if (coins > 0) {
                val nu = db.getUser(name)
                if (nu != null) { nu.coins = coins; db.saveUser(nu) }
            }
            toast("کاربر ساخته شد ✓")
            d.dismiss()
        })
    }

    private fun manageUsersSheet(): Unit = showSheet { c, d ->
        c.addView(tv("مدیریت کاربران", 18f, cText, true))
        c.addView(tv("هر تغییری که اینجا می‌دی روی همین گوشی ذخیره می‌شه. برای اینکه روی گوشی خود کاربر اعمال بشه، «💾 فایل اکانت» رو ذخیره کن و براش بفرست تا با «ورود با فایل» واردش بشه.", 12f, cSub).apply {
            setPadding(0, dp(4), 0, dp(8))
        })
        for (x in db.allUsers()) {
            val box = card()
            box.addView(tv("${x.name} (@${x.username})", 15f, cText, true))
            box.addView(tv(vipText(x) + "   🪙 ${x.coins}", 13f, cSub))

            // سکه
            val coinField = edit("سکه (مقدار نهایی)", x.coins.toString(), InputType.TYPE_CLASS_NUMBER)
            val r1 = LinearLayout(this)
            r1.addView(coinField, lp(0, WRAP, 1f))
            r1.addView(btn("ثبت سکه") {
                val v = coinField.text.toString().toIntOrNull()
                if (v == null || v < 0) { toast("عدد معتبر وارد کن"); return@btn }
                x.coins = v
                db.saveUser(x)
                d.dismiss(); manageUsersSheet()
            }.apply { layoutParams = lp(WRAP, WRAP, 0f, dp(2)) })
            box.addView(r1)

            // VIP
            if (x.role != "owner") {
                val vipField = edit("ماه VIP از امروز (۰ = لغو)", "1", InputType.TYPE_CLASS_NUMBER)
                val r2 = LinearLayout(this)
                r2.addView(vipField, lp(0, WRAP, 1f))
                r2.addView(btn("ثبت VIP") {
                    val v = vipField.text.toString().toIntOrNull()
                    if (v == null || v < 0) { toast("عدد معتبر وارد کن"); return@btn }
                    x.vipUntil = if (v == 0) 0L else System.currentTimeMillis() + v * 30L * DAY_MS
                    db.saveUser(x)
                    d.dismiss(); manageUsersSheet()
                }.apply { layoutParams = lp(WRAP, WRAP, 0f, dp(2)) })
                box.addView(r2)
            }

            val r3 = LinearLayout(this)
            r3.addView(btn("💾 فایل اکانت", Color.parseColor("#455A64")) { startExport(x.username) }
                .apply { layoutParams = lp(0, WRAP, 1f, dp(2)) })
            if (x.role != "owner") {
                r3.addView(btn("حذف", Color.GRAY) {
                    db.deleteUser(x.username)
                    d.dismiss(); manageUsersSheet()
                }.apply { layoutParams = lp(0, WRAP, 1f, dp(2)) })
            }
            box.addView(r3)
            c.addView(box)
        }
        c.addView(btn("بستن", Color.GRAY) { d.dismiss() })
    }

    // ---------- لیست ----------
    inner class MediaAdapter(private val items: List<Media>, private val showDesc: Boolean) : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int) = items[position].id.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val m = items[position]
            val row = LinearLayout(this@MainActivity).apply { setPadding(dp(12), dp(8), dp(12), dp(8)) }
            val img = ImageView(this@MainActivity).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
            row.addView(img, lp(dp(80), dp(115)))
            ImageLoader.load(m.cover, img)
            val col = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), 0, dp(12), 0)
            }
            col.addView(tv(m.title, 16f, cText, true).apply {
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
            })
            col.addView(tv(scoreText(m), 13f, ACCENT))
            if (m.info.isNotEmpty()) col.addView(tv(m.info, 12f, cSub))
            if (showDesc) col.addView(tv(m.desc, 12f, cSub).apply {
                maxLines = 4
                ellipsize = TextUtils.TruncateAt.END
            })
            row.addView(col, lp(0, WRAP, 1f))
            return row
        }
    }
}
