package com.example.myapp

import org.json.JSONObject

data class Kind(val label: String, val type: String, val country: String?, val key: String)

val KINDS = listOf(
    Kind("انیمه", "ANIME", null, "anime"),
    Kind("مانگا (ژاپن)", "MANGA", "JP", "manga"),
    Kind("مانهوا (کره)", "MANGA", "KR", "manhwa"),
    Kind("مانهوآ (چین)", "MANGA", "CN", "manhua")
)

// (برچسب فارسی، مقدار در AniList) — اولی یعنی «همه»
val GENRES = listOf(
    "همه" to "", "اکشن" to "Action", "ماجراجویی" to "Adventure", "کمدی" to "Comedy",
    "درام" to "Drama", "فانتزی" to "Fantasy", "ترسناک" to "Horror", "عاشقانه" to "Romance",
    "علمی‌تخیلی" to "Sci-Fi", "زندگی روزمره" to "Slice of Life", "ورزشی" to "Sports",
    "معمایی" to "Mystery", "ماورایی" to "Supernatural"
)

data class Media(
    val id: Int,
    val title: String,
    val cover: String,
    val score: Int,
    val desc: String,
    val info: String,
    val kindKey: String
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("title", title).put("cover", cover)
        .put("score", score).put("desc", desc).put("info", info)
        .put("kindKey", kindKey)

    companion object {
        fun fromJson(o: JSONObject) = Media(
            o.optInt("id"), o.optString("title"), o.optString("cover"),
            o.optInt("score"), o.optString("desc"), o.optString("info"),
            o.optString("kindKey", "anime")
        )
    }
}
