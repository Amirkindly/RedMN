package com.example.myapp

import org.json.JSONArray
import org.json.JSONObject

data class Frame(val id: String, val name: String, val price: Int, val color: Int)

val FRAMES = listOf(
    Frame("bronze", "برنزی", 1500, 0xFFCD7F32.toInt()),
    Frame("silver", "نقره‌ای", 3000, 0xFFC0C0C0.toInt()),
    Frame("gold", "طلایی", 6000, 0xFFFFC107.toInt()),
    Frame("diamond", "الماسی", 12000, 0xFF29B6F6.toInt()),
    Frame("royal", "سلطنتی", 25000, 0xFFAB47BC.toInt())
)

const val VIP_PRICE_TEXT = "۸۰٬۰۰۰ تومان در ماه"
const val BM_LIMIT = 350
const val BM_LIMIT_VIP = 500
const val DAY_MS = 86400000L

class User(
    val username: String,
    var name: String,
    val salt: String,
    var hash: String,
    val role: String,
    var vipUntil: Long,
    var coins: Int,
    var lastDaily: String,
    var frames: List<String>,
    var frame: String
) {
    fun toJson(): JSONObject = JSONObject()
        .put("username", username).put("name", name).put("salt", salt).put("hash", hash)
        .put("role", role).put("vipUntil", vipUntil).put("coins", coins)
        .put("lastDaily", lastDaily).put("frames", JSONArray(frames)).put("frame", frame)

    companion object {
        fun fromJson(o: JSONObject): User {
            val fa = o.optJSONArray("frames") ?: JSONArray()
            val fl = ArrayList<String>()
            for (i in 0 until fa.length()) fl.add(fa.getString(i))
            return User(
                o.getString("username"), o.optString("name"), o.getString("salt"), o.getString("hash"),
                o.optString("role", "user"), o.optLong("vipUntil", 0L), o.optInt("coins", 0),
                o.optString("lastDaily", ""), fl, o.optString("frame", "")
            )
        }
    }
}

fun isVip(u: User): Boolean = u.role == "owner" || u.vipUntil > System.currentTimeMillis()
fun bmLimit(u: User): Int = if (isVip(u)) BM_LIMIT_VIP else BM_LIMIT
